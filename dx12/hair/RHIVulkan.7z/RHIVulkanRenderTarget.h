#pragma once

#include "RHI/RHI.h"
#include "RHIVulkanCore.h"
#include "RHIVulkanDevice.h"

namespace RHI::RHIVulkan
{
	class RHIVulkanRenderTarget : public RHIRenderTarget
	{
	public:
	};
}
